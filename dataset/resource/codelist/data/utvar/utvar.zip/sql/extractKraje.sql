select
CONCAT(k.kod, '#00##', trim(k.kraje), '#0#')
from kraje k;